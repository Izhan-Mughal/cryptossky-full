const config = {
    baseURL: "https://cryptossky.weblinxsolution.com"
    // baseURL: "http://localhost/cryptossky"
}
export default config