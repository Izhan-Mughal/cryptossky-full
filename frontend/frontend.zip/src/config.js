const config = {
    baseURL: "https://cryptossky.weblinxsolution.com"
}
export default config